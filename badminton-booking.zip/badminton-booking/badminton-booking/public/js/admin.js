const dateInput = document.getElementById('dateInput');
const body = document.getElementById('adminBody');
dateInput.value = todayStr();

async function loadAll() {
  const { ok, data } = await api('/api/admin/bookings?date=' + dateInput.value);
  if (!ok) return;
  body.innerHTML = data.length ? '' : '<tr><td colspan="4" class="empty-text">ไม่มีการจองในวันนี้</td></tr>';
  data.forEach(b => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>สนามที่ ${b.court}</td><td>${b.slot} น.</td><td>${b.userName}</td>
      <td><select class="field">
        ${Object.keys(STATUS_TEXT).map(s => `<option value="${s}" ${s === b.status ? 'selected' : ''}>${STATUS_TEXT[s]}</option>`).join('')}
      </select></td>`;
    tr.querySelector('select').addEventListener('change', async e => {
      const res = await api('/api/admin/bookings/' + b.id, 'PATCH', { status: e.target.value });
      toast(res.data.message, !res.ok);
    });
    body.appendChild(tr);
  });
}

dateInput.addEventListener('change', loadAll);
renderNavbar().then(loadAll);
