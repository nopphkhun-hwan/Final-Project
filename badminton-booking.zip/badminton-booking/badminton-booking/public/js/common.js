async function api(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (res.status === 401 && !location.pathname.startsWith('/login')) { location.href = '/login'; }
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

function toast(text, isError) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = text;
  t.className = 'toast' + (isError ? ' error' : '');
  t.style.display = 'block';
  setTimeout(() => (t.style.display = 'none'), 2800);
}

const STATUS_TEXT = { waiting: 'รอคิว', playing: 'กำลังเล่น', done: 'เล่นเสร็จ', cancelled: 'ยกเลิก' };
const badge = s => `<span class="badge ${s}">${STATUS_TEXT[s]}</span>`;
const todayStr = () => new Date().toISOString().slice(0, 10);

async function renderNavbar() {
  const { ok, data } = await api('/api/me');
  if (!ok) return null;
  const nav = document.getElementById('navbar');
  nav.innerHTML = `
    <div class="brand">จองคอร์ดแบดมินตัน</div>
    <div class="menu">
      <a href="/home">จองคอร์ด</a>
      <a href="/my-bookings">การจองของฉัน</a>
      ${data.role === 'admin' ? '<a href="/admin">Admin</a>' : ''}
      <span>${data.name}</span>
      <button class="bth" id="logoutBtn">Logout</button>
    </div>`;
  document.getElementById('logoutBtn').addEventListener('click', async () => {
    await api('/api/logout', 'POST');
    location.href = '/login';
  });
  return data;
}
