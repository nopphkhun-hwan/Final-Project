const dateInput = document.getElementById('dateInput');
const list = document.getElementById('courtList');
dateInput.value = todayStr();
dateInput.min = todayStr();

function slotHtml(s) {
  const q = s.queue.length
    ? '<ol>' + s.queue.map(b => `<li>${b.userName} ${badge(b.status)}</li>`).join('') + '</ol>'
    : '<p class="empty">ยังไม่มีคิว</p>';
  return `<div class="slot-box"><h4>${s.slot} น.</h4>${q}</div>`;
}

async function loadCourts() {
  const { ok, data } = await api('/api/courts?date=' + dateInput.value);
  if (!ok) return;
  list.innerHTML = '';
  data.courts.forEach(c => {
    const card = document.createElement('div');
    card.className = 'court-card';
    card.innerHTML = `
      <h2>สนามที่ ${c.court}</h2>
      <img src="/img/court.jpg" alt="สนามที่ ${c.court}" class="img-court" onerror="this.style.display='none'">
      <p class="time-info">สนามนี้เริ่มเปิดใช้งาน 13.00 - 15.00 นาฬิกา</p>
      ${c.slots.map(slotHtml).join('')}
      <div class="book-row">
        <select class="field">${data.slots.map(s => `<option value="${s}">${s} น.</option>`).join('')}</select>
      </div>
      <button class="bth">จองสนาม</button>`;
    card.querySelector('button').addEventListener('click', async () => {
      const slot = card.querySelector('select').value;
      const res = await api('/api/bookings', 'POST', { court: c.court, date: dateInput.value, slot });
      toast(res.data.message, !res.ok);
      if (res.ok) loadCourts();
    });
    list.appendChild(card);
  });
}

dateInput.addEventListener('change', loadCourts);
renderNavbar().then(loadCourts);
