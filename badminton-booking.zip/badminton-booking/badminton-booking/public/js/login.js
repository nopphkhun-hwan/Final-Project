const msg = document.getElementById('msg');

async function doLogin() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const remember = document.getElementById('remember').checked;
  if (!username || !password) { msg.textContent = 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'; return; }
  const { ok, data } = await api('/api/login', 'POST', { username, password, remember });
  if (ok) { location.href = '/home'; }
  else { msg.className = 'msg'; msg.textContent = data.message; }
}

document.getElementById('loginBtn').addEventListener('click', doLogin);
document.getElementById('password').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
