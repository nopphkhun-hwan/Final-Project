const queueBody = document.getElementById('queueBody');
const historyBody = document.getElementById('historyBody');

async function loadMine() {
  const { ok, data } = await api('/api/bookings/mine');
  if (!ok) return;
  const active = data.filter(b => b.status === 'waiting' || b.status === 'playing')
    .sort((a, b) => (a.date + a.slot).localeCompare(b.date + b.slot));
  const past = data.filter(b => !(b.status === 'waiting' || b.status === 'playing'));

  queueBody.innerHTML = active.length ? '' : '<tr><td colspan="6" class="empty-text">ยังไม่มีคิวที่รออยู่</td></tr>';
  active.forEach(b => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${b.date}</td><td>${b.slot} น.</td><td>สนามที่ ${b.court}</td>
      <td>${b.queueNo}</td><td>${badge(b.status)}</td>
      <td>${b.status === 'waiting' ? '<button class="bth">ยกเลิก</button>' : ''}</td>`;
    const btn = tr.querySelector('button');
    if (btn) btn.addEventListener('click', async () => {
      if (!confirm('ต้องการยกเลิกการจองนี้หรือไม่?')) return;
      const res = await api(`/api/bookings/${b.id}/cancel`, 'PATCH');
      toast(res.data.message, !res.ok);
      loadMine();
    });
    queueBody.appendChild(tr);
  });

  historyBody.innerHTML = past.length ? '' : '<tr><td colspan="4" class="empty-text">ยังไม่มีประวัติ</td></tr>';
  past.forEach(b => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${b.date}</td><td>${b.slot} น.</td><td>สนามที่ ${b.court}</td><td>${badge(b.status)}</td>`;
    historyBody.appendChild(tr);
  });
}

renderNavbar().then(loadMine);
