const msg = document.getElementById('msg');

document.getElementById('regBtn').addEventListener('click', async () => {
  const name = document.getElementById('name').value.trim();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const { ok, data } = await api('/api/register', 'POST', { name, username, password });
  msg.className = ok ? 'msg ok' : 'msg';
  msg.textContent = data.message;
  if (ok) setTimeout(() => (location.href = '/login'), 1200);
});
